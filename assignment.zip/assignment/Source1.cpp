#include "String.h"

String::String()
{
	cout << "default constructor " << endl;
}

String::String(const String& st)
{
	cout << "parametrized constructor " << endl;
	int length = 0;
	for (int i = 0; st.array[i] != '\0'; i++)
	{
		length++;
    }
	array = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		array[i] = st.array[i];
	}
	array[length] = '\0';
}

String::String(const char* r)
{
	int length = 0;
	for (int i = 0; r[i] != '\0'; i++)
	{
		length++;
	}
	array = new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		array[i] = r[i];
	}
	array[length] = '\0';
}
String::String(const char* r, int s)
{
	array = new char[s];

	for (int i = 0; i < s; i++)
	{
		array[i] = r[i];
	}
	array[s] = '\0';
}

char String::c(int c)
{
	return array[c];
}

String String::subst(int position, int length) const
{
	String temp;
	int p;
	temp.array = new char[length];

	p = position;
	for (int i = 0; i < length; i++)
	{
		temp.array[i] = array[p];
		p++;
	}
	temp.array[length] = '\0';

	return temp;
}

String::String(const String& st, int position, int length)
{
	array = new char[length + 1];
	int p= position;
	for (int i = 0; i < length; i++)
	{
		array[i] = st.array[p];
		p++;
	}
	array[length] = '\0';
}

String::String(int n, char r)
{
	array = new char[n];

	for (int i = 0; i < n; i++)
	{
		array[i] = r;
	}
	array[n] = '\0';
}

int String::lengthgth()
{
	int length = 0;
	for (int i = 0; array[i] != '\0'; i++)
	{
		length++;
	}
	return length;
}



