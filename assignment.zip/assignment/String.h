#include<iostream>
using namespace std;
class String
{
	char* array;

public:
	String();
	String(const String& st);
	String(const String& st, int position, int length);
	String(const char* s);
	String(const char* s, int n);
	String(int n, char c);
	int lengthgth();
	char c(int c);
	String subst(int position, int length) const;

	friend ostream& operator<< (ostream& s, const String& st)
	{
		if (st.array != nullptr)
		{
			s << st.array << endl;
		}
		else
		{
			return s;
		}
	}

};


