#include "String.h"

int main()
{
	String s0("Initial string");
	String s1;
	String s2(s0);
	String s3(s0, 8, 3);
	String s4("A character sequence");
	String s5("Another character sequence", 12);
	String s6(10, 'x');
	String s7(10, '*');
	cout << "s1: " << s1 << endl << "s2: " << s2 << endl << "s3: " << s3 << endl << "s4: " << s4 << endl << "s5: " << s5 << endl << "s6a: " << s6 << endl << "s6b: " << s7 << endl;
	String st("Test string");
	String st2 = st.subst(3, 5); 
	cout << "The value in str is: " << st << endl;
	cout << "The size of str is: " << st.lengthgth() << endl;
	cout << "char at 5th location: " << st.c(5) << endl;
	cout << "char at 3nd location: " << st.c(3) << endl;
	cout << "Substring: " << st2 << endl;
	system("pause");
	return 0;
}